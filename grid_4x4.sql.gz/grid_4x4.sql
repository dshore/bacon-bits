-- MySQL dump 10.13  Distrib 5.1.61, for apple-darwin11.2.0 (i386)
--
-- Host: localhost    Database: grid_4x4
-- ------------------------------------------------------
-- Server version	5.1.61

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bigrams`
--

DROP TABLE IF EXISTS `bigrams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bigrams` (
  `bigram_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sense1_id` int(10) unsigned NOT NULL,
  `sense2_id` int(10) unsigned NOT NULL,
  `link_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`bigram_id`),
  UNIQUE KEY `sense1_id` (`sense1_id`,`sense2_id`,`link_id`),
  KEY `sense1_id_2` (`sense1_id`),
  KEY `sense2_id` (`sense2_id`),
  KEY `link_id` (`link_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bigrams`
--

LOCK TABLES `bigrams` WRITE;
/*!40000 ALTER TABLE `bigrams` DISABLE KEYS */;
INSERT INTO `bigrams` VALUES (1,1,2,1),(2,1,3,1),(3,4,5,1),(4,4,3,1),(5,4,6,1),(6,7,8,1),(7,7,9,1),(8,2,10,1),(9,9,11,1),(10,12,13,1),(11,12,8,1),(12,8,14,1),(13,14,13,1),(14,14,15,1),(15,15,10,1),(16,13,10,1),(17,5,16,1),(18,5,11,1),(19,11,6,1),(20,16,3,1);
/*!40000 ALTER TABLE `bigrams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `attribute` varchar(32) NOT NULL DEFAULT '',
  `value` varchar(32) NOT NULL DEFAULT 'False',
  PRIMARY KEY (`attribute`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES ('classname','Grid_Database'),('directed','False'),('row_str','ABCD'),('col_str','0123');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `directed_edges`
--

DROP TABLE IF EXISTS `directed_edges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `directed_edges` (
  `sense1_id` int(10) unsigned NOT NULL,
  `sense2_id` int(10) unsigned NOT NULL,
  `link_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `sense1_id` (`sense1_id`,`sense2_id`,`link_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directed_edges`
--

LOCK TABLES `directed_edges` WRITE;
/*!40000 ALTER TABLE `directed_edges` DISABLE KEYS */;
INSERT INTO `directed_edges` VALUES (1,2,1),(1,3,1),(2,1,1),(2,10,1),(3,1,1),(3,4,1),(3,16,1),(4,3,1),(4,5,1),(4,6,1),(5,4,1),(5,11,1),(5,16,1),(6,4,1),(6,11,1),(7,8,1),(7,9,1),(8,7,1),(8,12,1),(8,14,1),(9,7,1),(9,11,1),(10,2,1),(10,13,1),(10,15,1),(11,5,1),(11,6,1),(11,9,1),(12,8,1),(12,13,1),(13,10,1),(13,12,1),(13,14,1),(14,8,1),(14,13,1),(14,15,1),(15,10,1),(15,14,1),(16,3,1),(16,5,1);
/*!40000 ALTER TABLE `directed_edges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`link_id`),
  UNIQUE KEY `link` (`link`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
INSERT INTO `links` VALUES (1,'spatial');
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `senses`
--

DROP TABLE IF EXISTS `senses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `senses` (
  `sense_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`sense_id`),
  UNIQUE KEY `sense_id` (`sense_id`,`word_id`),
  KEY `word_id` (`word_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `senses`
--

LOCK TABLES `senses` WRITE;
/*!40000 ALTER TABLE `senses` DISABLE KEYS */;
INSERT INTO `senses` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9),(10,10),(11,11),(12,12),(13,13),(14,14),(15,15),(16,16);
/*!40000 ALTER TABLE `senses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `words`
--

DROP TABLE IF EXISTS `words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `words` (
  `word_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`word_id`),
  UNIQUE KEY `word` (`word`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `words`
--

LOCK TABLES `words` WRITE;
/*!40000 ALTER TABLE `words` DISABLE KEYS */;
INSERT INTO `words` VALUES (1,'A1'),(2,'A0'),(3,'A2'),(4,'B2'),(5,'B3'),(6,'C2'),(7,'D2'),(8,'D1'),(9,'D3'),(10,'B0'),(11,'C3'),(12,'D0'),(13,'C0'),(14,'C1'),(15,'B1'),(16,'A3');
/*!40000 ALTER TABLE `words` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-01-25 17:18:54
